#include "stdafx.h"
#include "actor.h"

CActor::CActor(void)
	: id(0)
	, x(0)
	, y(0)
	, name(_T(""))
	, type(0)
{
}

CActor::~CActor(void)
{
}
